# Project Alexandria: Your Sovereign Knowledge Engine

**Project Alexandria** is a powerful, private, and self-improving Intelligent Document Processing (IDP) platform. It goes beyond simple text extraction by using the **HONet/Prometheus architecture** to read, analyze, and **permanently learn** the knowledge within your documents, including **PDFs and text files**.

## The Vision: From Dumb Retrieval to True Understanding

Alexandria is a **sovereign AI that builds its own library of expertise** from your documents, running 100% on your local machine.

1.  **Ingestion:** You provide a document (`.pdf` or `.txt`).
2.  **Intelligent Extraction:** Alexandria's `CognitiveCore` uses the appropriate tool to extract clean text from the file.
3.  **Synthesis (The Meta-Mind):** A powerful local LLM reads the text and synthesizes its contents into a structured "Knowledge Report."
4.  **Learning (The HONet Principle):** This report is frozen into a tiny, permanent, and hyper-efficient `Knowledge Pack`—a specialist `Octave` that is now an expert on that document.
5.  **Querying:** When you ask a question, Alexandria routes it to the correct Knowledge Pack. The query is answered **instantly** using this small, specialized module, ensuring speed and privacy.

---

## Speed & Performance Benchmark
Alexandria's architecture gives it an insurmountable speed advantage over cloud-based RAG systems for querying previously learned documents.

| Metric | **Modern RAG (GPT-4 + Cloud Vector DB)** | **Project Alexandria (HONet)** |
| :--- | :--- | :--- |
| **Time for Subsequent Queries** | **Slow (5-15 seconds per query)** | **Lightning Fast (Milliseconds)** |
| **Data Privacy** | **Zero.** | **Absolute.** |

---

## How to Run the Live Test

### Step 1: Install and Run Ollama
1.  Download and install **Ollama** from [https://ollama.com/](https://ollama.com/).
2.  Pull a powerful model: `ollama pull llama3`
3.  Keep the Ollama server running.

### Step 2: Set Up the Alexandria Project
1.  Clone this repository and set up the Python environment.
2.  Install dependencies: `pip install -r requirements.txt`

### Step 3: Add Your Documents
Place any `.pdf` or `.txt` files you want the AGI to learn from into the `documents_to_learn/` directory. For example, add a file named `annual_report_2025.pdf`.

### Step 4: Run the AGI Platform
```bash
python run.py