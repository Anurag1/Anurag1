import ollama
import json

class LLMEngine:
    def __init__(self, model_name="llama3"):
        self.model_name = model_name
        print(f"Alexandria Meta-Mind initialized with model: '{self.model_name}'.")

    def get_json_response(self, system_prompt, user_prompt):
        try:
            response = ollama.chat(model=self.model_name, format="json", messages=[
                {'role': 'system', 'content': system_prompt}, {'role': 'user', 'content': user_prompt}
            ])
            return json.loads(response['message']['content'])
        except Exception as e:
            print(f"LLM JSON response error: {e}")
            return None
    
    def synthesize_knowledge_pack(self, document_content):
        print("  [Meta-Mind] Analyzing document and synthesizing knowledge...")
        system_prompt = "You are a world-class AI knowledge architect. Your job is to read a document and extract the most critical pieces of information as a structured JSON object of key-value pairs. This JSON will be used to train a specialized, permanent memory module. Be concise and accurate."
        user_prompt = f"Here is the document content:\n\n---\n{document_content}\n---\n\nPlease extract the key facts into a JSON object."
        return self.get_json_response(system_prompt, user_prompt)

    def answer_from_knowledge(self, question, knowledge_pack_content):
        system_prompt = "You are a helpful AI assistant. Your task is to answer the user's question based *only* on the provided 'Knowledge Pack' context. Do not use any external knowledge. If the answer is not in the context, say so."
        user_prompt = f"**Knowledge Pack Context:**\n{json.dumps(knowledge_pack_content, indent=2)}\n\n**User's Question:**\n{question}"
        try:
            response = ollama.chat(model=self.model_name, messages=[
                {'role': 'system', 'content': system_prompt}, {'role': 'user', 'content': user_prompt}
            ])
            return response['message']['content']
        except Exception as e:
            return f"Error with local LLM: {e}"