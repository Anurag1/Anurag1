import os
import fitz  # PyMuPDF
from .llm_engine import LLMEngine
from .honet_memory import HONetMemory

class Alexandria:
    def __init__(self):
        self.meta_mind = LLMEngine()
        self.memory = HONetMemory()
        self.document_path = "./documents_to_learn"
        os.makedirs(self.document_path, exist_ok=True)

    def _read_document_content(self, file_path):
        """
        Intelligently reads content from different file types.
        ALWAYS returns a tuple of (content, error).
        On success, error is None. On failure, content is None.
        """
        print(f"  -> Reading document: {file_path}")
        if file_path.lower().endswith('.pdf'):
            try:
                doc = fitz.open(file_path)
                content = ""
                for page in doc:
                    content += page.get_text()
                doc.close()
                # --- THIS LINE IS CORRECTED ---
                return content, None  # Return (content, None) on success
            except Exception as e:
                return None, f"Error reading PDF file: {e}"
        elif file_path.lower().endswith('.txt'):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                # --- THIS LINE IS CORRECTED ---
                return content, None  # Return (content, None) on success
            except Exception as e:
                return None, f"Error reading text file: {e}"
        else:
            return None, "Unsupported file type. Please use .txt or .pdf."

    def learn(self, document_filename):
        """The main flow for ingesting and learning from a document."""
        print(f"\n[Alexandria Core: Receiving new document to learn: '{document_filename}']")
        file_path = os.path.join(self.document_path, document_filename)
        
        if not os.path.exists(file_path):
            return f"Error: The file '{document_filename}' was not found in the '{self.document_path}' directory."
        
        content, error = self._read_document_content(file_path)
        if error:
            return error # If there was an error, return it to the user
        if content is None:
            return "An unknown error occurred while reading the file."

        # 1. Meta-Mind synthesizes the knowledge from the extracted text
        knowledge_data = self.meta_mind.synthesize_knowledge_pack(content)
        if not knowledge_data:
            return "Meta-Mind failed to synthesize knowledge from the document."
            
        # 2. HONet Memory freezes it into a permanent Knowledge Pack
        pack_name = self.memory.create_knowledge_pack(document_filename, knowledge_data)
        
        return f"Success! I have read, analyzed, and permanently learned the contents of '{document_filename}'. The knowledge is now stored in the '{pack_name}' Knowledge Pack."

    def query(self, prompt):
        """Answers questions by querying the learned Knowledge Packs."""
        try:
            pack_name, question = prompt.split(':', 1)
            pack_name = pack_name.strip().lower()
            question = question.strip()
        except ValueError:
            return "Error: Invalid query format. Use: '<knowledge_pack_name>: <your_question>'"

        # Clean up pack_name from potential file extensions
        pack_name = pack_name.replace('.txt', '').replace('.pdf', '')

        if pack_name not in self.memory.knowledge_packs:
            return f"Error: I have not learned a Knowledge Pack named '{pack_name}'. Available packs: {', '.join(self.memory.knowledge_packs.keys())}"

        print(f"  -> Querying Knowledge Pack '{pack_name}'...")
        knowledge_context = self.memory.knowledge_packs[pack_name]
        return self.meta_mind.answer_from_knowledge(question, knowledge_context)