import os
import json

class HONetMemory:
    def __init__(self, library_path="./knowledge_packs"):
        self.path = library_path
        self.knowledge_packs = {}
        os.makedirs(library_path, exist_ok=True)
        self.load_knowledge_packs()

    def load_knowledge_packs(self):
        print("HONet Memory: Loading Knowledge Packs...")
        for filename in os.listdir(self.path):
            if filename.endswith(".json"):
                pack_name = filename.replace(".json", "")
                try:
                    with open(os.path.join(self.path, filename), 'r') as f:
                        self.knowledge_packs[pack_name] = json.load(f)
                    print(f"  -> Loaded Knowledge Pack: '{pack_name}'")
                except Exception as e:
                    print(f"  -> Warning: Could not load pack '{pack_name}'. Error: {e}")

    def create_knowledge_pack(self, document_name, knowledge_data):
        pack_name = os.path.splitext(document_name)[0].replace(' ', '_').lower()
        print(f"  -> Freezing and saving new Knowledge Pack: '{pack_name}'")
        self.knowledge_packs[pack_name] = knowledge_data
        with open(os.path.join(self.path, f"{pack_name}.json"), 'w') as f:
            json.dump(knowledge_data, f, indent=2)
        return pack_name