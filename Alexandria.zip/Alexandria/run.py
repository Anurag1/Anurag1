from alexandria_core.cognitive_core import Alexandria
import os

def main():
    print("\n" + "="*60)
    print("      Project Alexandria: Your Sovereign Knowledge Engine")
    print("="*60)
    print("I can read, analyze, and permanently learn from .txt and .pdf documents.")
    print("\nCOMMANDS:")
    print("  - `learn <filename.pdf>`: Ingests a document from the 'documents_to_learn' folder.")
    print("  - `<pack_name>: <question>`: Asks a question to a learned Knowledge Pack.")
    print("  - `list`: Shows all learned Knowledge Packs.")
    print("  - `exit`: Shuts down the platform.")
    print("-"*60)
    
    # Create a sample text file for convenience
    sample_txt_path = "documents_to_learn/sample_report.txt"
    if not os.path.exists(sample_txt_path):
        print("Creating a sample .txt document for you to learn...")
        os.makedirs("documents_to_learn", exist_ok=True)
        with open(sample_txt_path, "w") as f:
            f.write("Project Titan Q3 Report. Revenue was $5.2 million. The lead engineer was Dr. Evelyn Reed.")
    
    print("\nPlace your .pdf and .txt files in the 'documents_to_learn' directory.")
    
    alexandria_agi = Alexandria()

    while True:
        try:
            prompt = input("\n[You]> ")
            if prompt.lower() == 'exit':
                break
            elif prompt.lower().startswith('learn '):
                filename = prompt.split(' ', 1)[1]
                response = alexandria_agi.learn(filename)
            elif prompt.lower() == 'list':
                packs = alexandria_agi.memory.knowledge_packs.keys()
                response = f"Available Knowledge Packs: {', '.join(packs)}" if packs else "No Knowledge Packs have been learned yet."
            elif ':' in prompt:
                response = alexandria_agi.query(prompt)
            else:
                response = "Invalid command. Please use 'learn <filename>', '<pack_name>: <question>', or 'list'."
            
            print(f"\n[Alexandria]> {response}")
        except Exception as e:
            print(f"A critical error occurred: {e}")

if __name__ == "__main__":
    main()